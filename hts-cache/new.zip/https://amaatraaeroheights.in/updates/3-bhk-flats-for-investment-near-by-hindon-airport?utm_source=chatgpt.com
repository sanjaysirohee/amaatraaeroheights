<!DOCTYPE html>
<html lang='en'>

<head>
    <meta charset='UTF-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no, maximun-scale=1'>
    <title>
        Updates | 3-bhk-flats-for-investment-near-by-hindon-airport    </title>

    <meta name="keywords" content="Healthcare" >
    <meta name='description' content='This is the Product Detail page'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
<link rel="stylesheet" href="https://amaatraaeroheights.in/public/assets/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.css" integrity="sha512-6lLUdeQ5uheMFbWm3CP271l14RsX1xtx+J5x2yeIDkkiBpeVTNhTqijME7GgRKKi6hCqovwCoBTlRBEC20M8Mg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.css" integrity="sha512-wR4oNhLBHf7smjy0K4oqzdWumd+r5/+6QO/vDda76MW5iug4PT7v86FoEkySIJft3XA0Ae6axhIvHrqwm793Nw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
<link rel="stylesheet" href="https://amaatraaeroheights.in/public/theme1/assets/css/style.css">
<link rel="stylesheet" href="https://amaatraaeroheights.in/public/assets/css/color.css">
<link rel="stylesheet" href="https://amaatraaeroheights.in/public/assets/css/new.font.family.css">

<link href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css" ref="stylesheet" />
<!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" /> -->
<!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" /> -->
<!-- <link href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick.min.css" rel="stylesheet" media="all" /> -->
<!-- <link href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick-theme.css" rel="stylesheet" media="all" /> -->    <style>
    .card-body {
        padding: 0px !important;
    }

    a {
        text-decoration: none !important;
    }
</style>

    <style>
        :root {
            --header_background: #26a1df;
            --header_text: #ffffff;
            --navbar_background: #ffffff;
            --navbar_text: #26a1df;
            --searchbar_color: #ffffff;
            --searchbar_button_color: #000000;
            --inquiry_button_color: #074597;
            --footer_background: #ffffff;
            --footer_text_color: #26a1df;
            --copyright_background: #050505;
            --copyright_text_color: #ffffff;
        }
        body.theme-custom {
            --bs-orange-100: #23e7bf;
            --bs-primary-rgb: 35,231,191;
        }
        .custom-text-color p,
        .custom-text-color {
            color: #050505 !important;
        }
    </style>
</head>

<body class="theme-custom">
    <div class="header-background-color ">
    <div class="container-fluid header-padding d-flex justify-content-between py-1">
        <div class="first-columns d-flex align-items-center">
            <ul class="links list-unstyled  d-flex mb-0">
                <li class="pe-4"> <a href="" class="text-light header-text"><i class="fa-solid fa-phone"></i></a> </li>
                <li class="pe-4 "><a href="tel:+91 97111 33226" class="header-text text-decoration-none fw-bold number-hover"> +91 97111 33226</a></li>
                <li class="pe-4"> <a target="_blank" href="https://wa.me/+91 97111 33226?text=Hi%27,%20like%20to%20chat%20with%20you" class=" header-text text-success"><i class="fa-brands fa-whatsapp fs-5"></i></a> </li>
                <li class="pe-4"> <a href="" class="text-light header-text"> <i class="fa-solid fa-comment-dots fs-5"></i></a></li>
            </ul>
        </div>

        <div class="second-columns">
            <ul class="links list-unstyled text-light d-flex mb-0">
                <li>
                    <button class="btn inquiry_button_color search-btn rounded-pill ms-2 responsive-btn btn-sm" data-bs-target="#inquiryModal" data-bs-toggle="modal" type="submit">Make An Inquiry</button>
                </li>
            </ul>
        </div>
    </div>
</div>
 
<input type="hidden" id="baseUrl" value="https://amaatraaeroheights.in" />
<input type="hidden" id="checkError" value="0" />

<nav class="navbar navbar-expand-md navbar-background p-0 sticky-top " style="top: -1px;">
    <div class="container-fluid header-padding">
        <a class="navbar-brand" href="https://amaatraaeroheights.in">
        <img class="logo horizontal-logo assets-img-header-logo-png" src="https://amaatraaeroheights.in/public/uploads/img/business_logo/1757564635_6411623b5b9f8af7bf39.png" alt="forecastr logo" width="" height="70px">
        </a>
        <button class="navbar-toggler" type="button" style="line-height:inherit;" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"><i class="fa-solid fa-bars"></i></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item  m-0">
                <a class="nav-link  text-nowrap" target="" href="https://amaatraaeroheights.in/" 
                   >
                    Home                </a>
                            </li>
                    <li class="nav-item  m-0">
                <a class="nav-link  text-nowrap" target="" href="https://amaatraaeroheights.in/about" 
                   >
                    About Us                </a>
                            </li>
                    <li class="nav-item  m-0">
                <a class="nav-link  text-nowrap" target="" href="https://amaatraaeroheights.in/project_features" 
                   >
                    Project Features                </a>
                            </li>
                    <li class="nav-item  m-0">
                <a class="nav-link  text-nowrap" target="" href="https://amaatraaeroheights.in/floor_plan" 
                   >
                    Floor Plan                </a>
                            </li>
                    <li class="nav-item  m-0">
                <a class="nav-link  text-nowrap" target="" href="https://amaatraaeroheights.in/master_plan" 
                   >
                    Master Plan                </a>
                            </li>
                    <li class="nav-item  m-0">
                <a class="nav-link  text-nowrap" target="" href="https://amaatraaeroheights.in/contact" 
                   >
                    Contact                </a>
                            </li>
        
   
    <li class="nav-item m-0">
    <a class="nav-link text-nowrap" href="https://drive.google.com/file/d/1JS80jO1peED2n7ckInxlY0VdAB9oDMKo/view" target="_blank">
        Payment Plan
    </a>
</li>


    <li class="w-75">
        <form class="form-inline d-flex" method="post" action="search">
            <input name="search" value="" id="search" 
                   class="form-control mr-sm-2 rounded-0 searchbar_color searchbar" 
                   type="search" placeholder="Search" aria-label="Search" 
                   style="width: 200px!important;" required>
            <button class="btn searchbar_button_color search-btn my-2 my-sm-0 rounded-0" type="submit">
                Search
            </button>
        </form>
    </li>
</ul>

        </div>
    </div>
</nav>

<!-- Modal -->
<div class="modal fade" id="inquiryModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header modal-bg-color">
                <h5 class="modal-title text-light fw-bold" id="exampleModalLabel">Make an Inquiry</h5>
                <button type="button" class="btn-close bg-light" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form class="contact-form">
                    <div class="row">
                        <div class="form-group col-md-12">
                            <label for="name">Your Name</label>
                            <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required="">
                        </div>
                        <div class="form-group col-md-12 mt-3">
                            <label for="name">Mobile Number</label>
                            <input type="text" class="form-control" maxlength="10" name="number" id="number" placeholder="Mobile number" required="">
                        </div>
                        <div class="form-group col-md-12 mt-3">
                            <label for="enqEmail">Email</label>
                            <input type="email" class="form-control" name="enqEmail" id="enqEmail" placeholder="Email address" required="">
                        </div>
                    </div>
                    <div class="form-group mt-3">
                        <label for="name">Your Message</label>
                        <textarea class="form-control" name="message" id="message" rows="3" required=""></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary rounded-pill" data-bs-dismiss="modal">Close</button>
                <button type="button" id="sendMsg" class="btn btn-color text-white rounded-pill ">
                    Send
                </button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="testimonialModalShow" tabindex="-1" role="dialog" aria-labelledby="testimonialModalShowLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="testimonialModalShowLabel">Testimonial</h5>
            </div>
            <div class="modal-body" id="modalBody">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary testimonialModalClose" >Close</button>
            </div>
        </div>
    </div>
</div>
    <!-- Page Content -->
    <div class="update-page">
    <section>
        <div class="row mx-auto">
            <div class="col-md-12 p-0" data-aos="fade-up" data-aos-duration="1000">
                <div class="heroContent">
                    <h1 class="fw-bold text-color">3 BHK Flats for Investment near by Hindon Airport</h1>
                    <div>
                        <p class="text-white">
                            <a class="text-decoration-none fw-bold text-light " href="https://amaatraaeroheights.in/">
                                Home-> updates->
                            </a>
                            3-bhk-flats-for-investment-near-by-hindon-airport                        </p>
                    </div>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="row content pt-3">
                <div class="col-md-8 pt-4 pt-lg-0" data-aos="flip-left" data-aos-duration="1000" >
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1757912043_b3a0ec4abf8fce126259.jpg" width="100%" height="" alt="">

                    <div class="bg-dark p-2 my-4 ">
                        <h4 class="text-color pt-1 fw-bold text-center">3 BHK Flats for Investment near by Hindon Airport</h4>
                    </div>
                    <div class="text-alignment">
                        <span class="text-gray">By : Admin Date : 15-Sep-2025</span>
                        <div class="">
                            <p>Aero Heights enjoys a strategic location in Koyal Enclave, Ghaziabad, making it one of the most sought-after residential destinations in NCR. The project ensures seamless connectivity to major hubs while offering a peaceful living environment.</p>

<ul>
	<li>&nbsp;Connectivity to Delhi &amp; Noida via NH-24 &amp; Delhi&ndash;Meerut Expressway</li>
	<li>&nbsp;Just 10 mins from Anand Vihar ISBT &amp; Railway Station</li>
	<li>&nbsp;15 mins from Hindon Airport</li>
	<li>&nbsp;Close to proposed metro stations and rapid transport corridors</li>
	<li>&nbsp;Surrounded by reputed schools, colleges &amp; coaching centers</li>
	<li>&nbsp;Proximity to hospitals, shopping malls &amp; daily conveniences</li>
	<li>&nbsp;Easy access to business districts &amp; IT hubs of Noida &amp; Ghaziabad</li>
</ul>
                        </div>
                    </div>

                </div>
                <div class="col-md-4" data-aos="flip-right" data-aos-duration="1000" style= "max-height: 600px;overflow-y: auto;">
                                                <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/2-bhk-luxury-flats-in-koyal-enclave-ghaziabad">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1757911498_b470c1c33d1ec4019b59.jpg" style="width:50px;" />
                                        2 BHK Luxury Flats in Koyal Enclave Ghaziabad                                    </p>
                                </a>
                                <p class="mb-0">26-Dec-2022</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/pre-launch-3-bhk-flats-in-koyal-enclave-ghaziabad">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1757911648_5b118a53b27fa75fbccb.jpg" style="width:50px;" />
                                        Pre Launch 3 BHK Flats in Koyal Enclave Ghaziabad                                    </p>
                                </a>
                                <p class="mb-0">15-Sep-2025</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/under-budget-3-bhk-flats-on-sale-in-koyal-enclave-ghaziabad">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1757911835_dd5691325a4742a512d8.jpg" style="width:50px;" />
                                        Under Budget 3 BHK flats on sale in Koyal Enclave Ghaziabad                                    </p>
                                </a>
                                <p class="mb-0">15-Sep-2025</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/budget-2-and-3-bhk-flats-for-purchase-near-hindon-airport">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1757911935_cf27adfca888c6ed691f.jpg" style="width:50px;" />
                                        Budget 2 and 3 BHK Flats for purchase near hindon Airport                                    </p>
                                </a>
                                <p class="mb-0">15-Sep-2025</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/3-bhk-flats-for-investment-near-by-hindon-airport">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1757912043_b3a0ec4abf8fce126259.jpg" style="width:50px;" />
                                        3 BHK Flats for Investment near by Hindon Airport                                    </p>
                                </a>
                                <p class="mb-0">15-Sep-2025</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/budget-2-bhk-luxury-flats-for-sale-in-koyal-enclave-ghaziabad">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1757912161_8fb88b679bbb52eccdbe.jpg" style="width:50px;" />
                                        Budget 2 bhk Luxury Flats for sale in koyal enclave Ghaziabad                                    </p>
                                </a>
                                <p class="mb-0">15-Sep-2025</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/amaatra-aero-heights">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1758540309_839c2f3d2179e5f822d7.jpg" style="width:50px;" />
                                        Amaatra Aero Heights                                    </p>
                                </a>
                                <p class="mb-0">22-Sep-2025</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/budget-3-bhk-flats-near-hindon-airport-ghaziabad">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1758716172_04d3bc05ca7af52ba23e.jpg" style="width:50px;" />
                                        budget 3 bhk flats near hindon airport Ghaziabad                                    </p>
                                </a>
                                <p class="mb-0">24-Sep-2025</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/affordable-4-bhk-apartment-in-koyal-enclave-ghaziabad">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1759220521_12c7db0b58348cc5e475.png" style="width:50px;" />
                                        Affordable 4 bhk Apartment in koyal enclave ghaziabad                                    </p>
                                </a>
                                <p class="mb-0">30-Sep-2025</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/buy-3bhk-apartment-in-amaatraa-aero-heights-koyal-enclave">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1759493730_a7ad6f409d692635837a.png" style="width:50px;" />
                                        Buy 3bhk apartment in Amaatraa Aero heights Koyal Enclave                                    </p>
                                </a>
                                <p class="mb-0">03-Oct-2025</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/2-and-3-bhk-flats-near-by-koyal-enclave-ghaziabad">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1759756983_6456c7c5f876066253b7.png" style="width:50px;" />
                                        2 and 3 BHK flats near by Koyal Enclave Ghaziabad	                                    </p>
                                </a>
                                <p class="mb-0">06-Oct-2025</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/pre-launch-2-bhk-flats-in-koyal-enclave-ghaziabad-">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1760446302_37959b640c8cb7394ab3.jpg" style="width:50px;" />
                                        Pre Launch 2 BHK Flats in Koyal Enclave Ghaziabad                                     </p>
                                </a>
                                <p class="mb-0">14-Oct-2025</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/amaatra-aero-heights-koyal-enclave">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1763114738_e1057a53d6e27a3fb5b6.webp" style="width:50px;" />
                                        Amaatra Aero Heights koyal enclave                                    </p>
                                </a>
                                <p class="mb-0">14-Nov-2025</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/3-bhk-flat-near-hindon-airpot">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1763982149_d132fc0278374e8529af.webp" style="width:50px;" />
                                        3 bhk flat near hindon airpot                                    </p>
                                </a>
                                <p class="mb-0">24-Nov-2025</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/flats-for-sale-in-koyal-enclave">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1764240233_420bb4303ce8d0170a14.webp" style="width:50px;" />
                                        Flats for sale in Koyal Enclave                                    </p>
                                </a>
                                <p class="mb-0">27-Nov-2025</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/amaatra-aero-heights-payment-plan">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1764586289_37965c8084c031ac21b6.webp" style="width:50px;" />
                                        amaatra aero heights payment plan                                    </p>
                                </a>
                                <p class="mb-0">01-Dec-2025</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/amaatra-aero-heights-connectivity">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1764672578_eaa274f0ddfd6b9e58ae.webp" style="width:50px;" />
                                        Amaatra Aero Heights Connectivity                                    </p>
                                </a>
                                <p class="mb-0">02-Dec-2025</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/amaatra-aero-heights-construction-update">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1765175677_f8618f63a55d977469a6.webp" style="width:50px;" />
                                        amaatra aero heights construction update                                    </p>
                                </a>
                                <p class="mb-0">08-Dec-2025</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/amaatra-aero-heights-apartment">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1765448462_fbc0b0a46cce59cb6032.webp" style="width:50px;" />
                                        amaatra aero heights apartment                                    </p>
                                </a>
                                <p class="mb-0">11-Dec-2025</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/amaatra-aero-heights-latest-update">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1765780349_d9e5aee79d1a6595fee9.webp" style="width:50px;" />
                                        Amaatra Aero Heights latest update                                    </p>
                                </a>
                                <p class="mb-0">15-Dec-2025</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/2-bhk-flats-for-sale-in-koyal-enclave">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1766400683_fcbab494580b93aebea3.webp" style="width:50px;" />
                                        2 BHK Flats for Sale in Koyal Enclave                                    </p>
                                </a>
                                <p class="mb-0">22-Dec-2025</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/new-residential-projects-in-ghaziabad-near-airport">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1766487197_74ad38166348f3240da7.webp" style="width:50px;" />
                                        New Residential Projects in Ghaziabad Near Airport                                    </p>
                                </a>
                                <p class="mb-0">23-Dec-2025</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/httpsamaatraaeroheightsin">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1766748604_83219c54b15c983e2c6d.jpg" style="width:50px;" />
                                        https://amaatraaeroheights.in/                                    </p>
                                </a>
                                <p class="mb-0">26-Dec-2025</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/residential-projects-near-ghaziabad-airport">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1766748787_9571570705ccdb58a05e.jpg" style="width:50px;" />
                                        Residential Projects Near Ghaziabad Airport                                    </p>
                                </a>
                                <p class="mb-0">26-Dec-2025</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/amaatra-aero-heights-ghaziabad">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1768372851_552023007149f02629a4.webp" style="width:50px;" />
                                        Amaatra Aero Heights Ghaziabad                                    </p>
                                </a>
                                <p class="mb-0">14-Jan-2026</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/residential-project-ghaziabad-airport">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1769080525_f2e2074d25e543fddda2.webp" style="width:50px;" />
                                        residential project Ghaziabad airport                                    </p>
                                </a>
                                <p class="mb-0">22-Jan-2026</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/2-bhk-flats-in-koyal-enclave-ghaziabad">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1769667961_2da00b9346d684d98012.jpg" style="width:50px;" />
                                        2 BHK flats in Koyal Enclave Ghaziabad                                    </p>
                                </a>
                                <p class="mb-0">29-Jan-2026</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/residential-project-koyal-enclave">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1770893596_a586f1fc9636dfca6a5f.webp" style="width:50px;" />
                                        residential project Koyal Enclave                                    </p>
                                </a>
                                <p class="mb-0">12-Feb-2026</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/3bhk-apartment-for-sale-in-koyal-enclave-ghaziabad">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1771496538_64ceb8f0d54d800087de.jpg" style="width:50px;" />
                                        3BHK apartment for sale in Koyal Enclave Ghaziabad                                    </p>
                                </a>
                                <p class="mb-0">19-Feb-2026</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/flats-in-koyal-enclave-ghaziabad">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1775537329_900b60ccf0ed36ad1578.webp" style="width:50px;" />
                                        Flats in Koyal Enclave Ghaziabad                                    </p>
                                </a>
                                <p class="mb-0">07-Apr-2026</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/amaatra-aero-heights-price-list-and-floor-plan">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1775627832_61da1257813a303ae2af.jpg" style="width:50px;" />
                                        Amaatra Aero Heights Price List and Floor Plan                                    </p>
                                </a>
                                <p class="mb-0">08-Apr-2026</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/2-bhk-flats-near-koyal-enclave-ghaziabad">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1777351475_007e6d8ede330ba3c6ae.jpg" style="width:50px;" />
                                        2 BHK Flats Near Koyal Enclave Ghaziabad                                    </p>
                                </a>
                                <p class="mb-0">28-Apr-2026</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/pre-launch-3bhk-flats-in-koyal-enclave-ghaziabad">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1777352657_70130e33716ecd6d884a.jpg" style="width:50px;" />
                                        Pre Launch 3BHK Flats in Koyal Enclave Ghaziabad                                    </p>
                                </a>
                                <p class="mb-0">28-Apr-2026</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/3-bhk-flats-in-ghaziabad">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1778129954_73d4376f41aef7d15639.jpg" style="width:50px;" />
                                        3 BHK flats in Ghaziabad                                    </p>
                                </a>
                                <p class="mb-0">07-May-2026</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/premium-flats-in-ghaziabad">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1778480790_f04fd1123c33c4031c26.jpg" style="width:50px;" />
                                        premium flats in Ghaziabad                                    </p>
                                </a>
                                <p class="mb-0">11-May-2026</p>
                            </div>
                            <hr class="w-100 m-0">
                                                        <div class="p-3 hover-bg">
                                                            <a href="https://amaatraaeroheights.in/updates/2-bhk-flats-in-koyal-enclave">
                                    <p class="mb-0">
                                        <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1781070276_06d28c43740c897d68b8.webp" style="width:50px;" />
                                        2 BHK flats in Koyal Enclave                                    </p>
                                </a>
                                <p class="mb-0">10-Jun-2026</p>
                            </div>
                            <hr class="w-100 m-0">
                                            </div>
            </div>
        </div>
    </section>
    
        </div>

    <style>
    .fb-box{
        height: 350px;
        width:360px;
    }
    .mybox {
        margin:40px !important;
    }
    @media only screen and (max-width: 767px) {
        #facebook-iframe {
            width: 100% !important;
            height: 500px !important; /* Adjust height as needed for portrait mode */
        }
        .fb-box{
        height: 600px;
        width:360px;
        }
         .mybox {
        margin:0px !important;
        }
    }
</style>
<footer id="footer">
    <div class="footer-top footer-background text-light py-5">
          <div class="container mybox">
            <div class="row g-5 justify-content-center">
                <div class="col-md-6">
                    <div class="footer-info shadow text-center">
                        <h3 class="text-center custom-text-color fw-bold">Get In Touch</h3>
                        <div class= "row">
                            
                            <div class="col-md-12">
                                <p class="pb-3 m-0">
                                    <em>
                                        Corporate Office Address :- GH-02, Jaipuria Sunrise Greens, Opp Manipal Hospital, Ghaziabad - 201002.<br>RERA No- UPRERAPRJ15601<br>www.up-rera.in                                    </em>
                                </p>
                                <strong>Phone:</strong> +91 97111 33226, <br> <strong>Email:</strong> sales@amatragroup.com<br>
                                </p>
                            </div>
                            <div class="col-md-12">
                                <p class="pb-3 m-0">
                                    <em>
                                        Regional Corporate Office: - Unit Number - 511, SG Brave Road, Wagle Estate, Thane (West), Maharashtra, 400604.                                    </em>
                                </p>
                                
                                                                         <strong>Alternate Number: </strong> 18001034240<br>
                                                                     <strong>Alternate Email: </strong> maninderbansal@gmail.com<br>
                                                            </div>
                        </div>
                    </div>
                </div> 
                
                <!-- <div class="col-md-3 newsletter">
                    <h3 class="fw-bold custom-text-color">Our Newsletter</h3>
                    <div id="business_description">
                        
                    <p></p>
                    </div>
                    <form action="" method="post">
                        <input type="email" name="email" class="py-1 border-0 searchbar_color">
                        <input type="submit" class="btn-color custom-text-color border-0 py-1 rounded" value="Subscribe">
                    </form>
                </div> -->

                <div class="col-md-3 quick-links text-center">
                    <h3 class="fw-bold custom-text-color">Quick Links</h3>
                    <div>
                        <ul class="list-unstyled" style="padding-left: 0pt;">
                            <li style="text-decoration: underline; padding-bottom:20px; font-size:18px;"><a class="custom-text-color" href="">Home</a></li><li style="text-decoration: underline; padding-bottom:20px; font-size:18px;"><a class="custom-text-color" href="about">About Us</a></li><li style="text-decoration: underline; padding-bottom:20px; font-size:18px;"><a class="custom-text-color" href="project_features">Project Features</a></li><li style="text-decoration: underline; padding-bottom:20px; font-size:18px;"><a class="custom-text-color" href="floor_plan">Floor Plan</a></li><li style="text-decoration: underline; padding-bottom:20px; font-size:18px;"><a class="custom-text-color" href="master_plan">Master Plan</a></li><li style="text-decoration: underline; padding-bottom:20px; font-size:18px;"><a class="custom-text-color" href="contact">Contact</a></li>                        </ul>
                    </div>
                </div>





                            <div class="col-md-3">
                                <div class="fb-box mx-auto" style="background-color: #f8f9fa; padding: 10px; border-radius: 5px; height:auto; margin-bottom:5px;">
                                    <div class="social-links text-center footer-center">
                                        <a target="_blank" href="https://twitter.com/TCS?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor" class="twitter text-light me-1 rounded text-center fs-6" style="color: #1DA1F2 !important; font-size: 24px;">
                                            <i class="fa-brands fa-twitter-square"></i>
                                        </a>
                                        <a target="_blank" href="https://www.facebook.com/Amaatragroup" class="facebook text-light me-1 rounded text-center fs-6" style="color: #1877F2!important; font-size: 24px;">
                                            <i class="fa-brands fa-facebook-square"></i>
                                        </a>
                                        <a target="_blank" href="https://www.instagram.com/tcsglobal/?hl=en" class="instagram text-light me-1 rounded text-center fs-6" style="color: #C13584 !important; font-size: 24px;">
                                            <i class="fa-brands fa-instagram-square"></i>
                                        </a>
                                        <a target="_blank" href="https://www.youtube.com/channel/UCaHyiyvJp4hhPNhIU7r9uqg" class="google-plus text-light me-1 rounded text-center fs-6" style="color: #FF0000 !important; font-size: 24px;">
                                            <i class="fa-brands fa-youtube"></i>
                                        </a>
                                        <a target="_blank" href="https://in.linkedin.com/company/tata-consultancy-services" class="linkedin text-light me-1 rounded text-center fs-6" style="color: #0077B5 !important; font-size: 24px;">
                                            <i class="fa-brands fa-linkedin ml-2"></i>
                                        </a>
                                    </div>
                                         <iframe id="facebook-iframe" style="margin: auto; display: flex; margin-bottom:10px:width: 100%;height:100%;" src="https://www.facebook.com/plugins/page.php?href=https://www.facebook.com/Amaatragroup&tabs=timeline&width=345&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="270" height="300" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></iframe>
                                  </div>
                                  <section class="newsletter-section text-center py-3">
                                <h3 class="fw-bold custom-text-color w-100">Our Newsletter</h3>
                                <hr class="m-auto bg-danger mb-3" style="width: 80px; height: 5px">
                                    <marquee behavior="scroll" direction="left" style="width:400px;">
                                        <!-- Newsletter content here -->
                                        Aero Heights enjoys a strategic location in Koyal Enclave, Ghaziabad, making it one of the most sought-after residential destinations in NCR. The project ensures seamless connectivity to major hubs while offering a peaceful living environment.                                    </marquee>
                                </section>
                                  
                             </div>
            </div>
        </div>
        
    </div>
</footer>



<section class="copyright-background">
    <div class="row">
        <div class="col-md-12 text-center copyright-text">
        © 2026 Advertising India        </div>
    </div>
</section>



<!-- <a id="button" class="scroll-to-top scroll-to-target  position-fixed text-light fs-6 text-center rounded-circle border-0" data-target="html">
    <span class="fa fa-arrow-up">
    </span>
</a> -->    <script src="https://amaatraaeroheights.in/public/assets/js/jquery.min.js"></script>
<script src="https://amaatraaeroheights.in/public/assets/js/bootstrap.bundle.min.js"></script>
<script src="https://amaatraaeroheights.in/public/assets/js/jquery.validate.min.js"></script>
<script src="https://amaatraaeroheights.in/public/assets/js/additional-methods.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js" integrity="sha512-XtmMtDEcNz2j7ekrtHvOVR4iwwaD6o/FUJe6+Zq+HgcCsk3kj4uSQQR8weQ2QVj1o0Pk6PwYLohm206ZzNfubg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="https://amaatraaeroheights.in/public/assets/js/script.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.min.js"></script>

<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick.min.js"></script> -->
<!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script></script> -->
<script type="text/javascript" src="https://amaatraaeroheights.in/public/theme1/assets/js/pages/common.js"></script>
    <script>
    $(function() {
        AOS.init();
    });
</script>


    
            <script defer>
            $(function() {
                var eppathurl = window.location.origin + window.location.pathname;
                var eptagmanage = new XMLHttpRequest();
                var getDataUrl = "https://amaatraaeroheights.in" + '/posts/getAllData/';
                var currentUrl = "https://amaatraaeroheights.in/updates/3-bhk-flats-for-investment-near-by-hindon-airport";
                getDataUrl = btoa(getDataUrl);
                eptagmanage.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                        if (this.response !== 0) {
                            var temp = this.response.split("||||||||||");
                            $("head").find("title").remove();
                            $('head').append(temp[0]);
                            $("body").append(temp[1]);
                        }
                    }
                };
                eptagmanage.open("POST", atob(getDataUrl) + btoa(currentUrl));
                eptagmanage.send();
            });

            document.addEventListener('DOMContentLoaded', function() {
                var keywords = [];
                if (keywords && keywords.length > 0) {
                    var keywordString = keywords.map(function(keyword) {
                        return keyword.keyword;
                    }).join(', ');
                    var metaKeywordsTag = document.createElement('meta');
                    metaKeywordsTag.name = 'keywords';
                    metaKeywordsTag.content = keywordString;
                    document.head.appendChild(metaKeywordsTag);
                }
            });
        </script>
    </body>
</html>
