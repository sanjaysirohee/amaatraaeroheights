<!DOCTYPE html>
<html lang='en'>

<head>
    <meta charset='UTF-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no, maximun-scale=1'>
    <title>
        Home    </title>

    <meta name="keywords" content="amaatra aero heights flats in koyal enclave Ghaziabad, ammatra aero heights in koyal enclave ghaziabad, budget 3 bhk flats near hindon airport Ghaziabad, 2 and 3 bhk flats near hindon airport ghaziabad, pre launche luxury flats for investment in koyal enclave ghaziabad, affordable 2 bhk flats in koyal enclave ghaziabad, 2 bhk flats on high rise society in koyal enclave ghaziabad, premium flats near by delhi in koyal enclave ghaziabad, 2 and 3 BHK flats near by koyal enclave ghaziabad, luxury flats for sale with swimming pool in koyal enclave ghaziabad, luxury flats on sale with kids park in koyal enclave ghaziabad, under budget luxury flats for investment in koyal enclave ghaziabad, budget 3 bhk flats near hindon airport Ghaziabad, 2 and 3 bhk flats near hindon airport ghaziabad, pre launche luxury flats for investment in koyal enclave ghaziabad, affordable 2 bhk flats in koyal enclave ghaziabad, 2 bhk flats on high rise society in koyal enclave ghaziabad, premium flats near by delhi in koyal enclave ghaziabad, 2 and 3 BHK flats near by koyal enclave ghaziabad, luxury flats for sale with swimming pool in koyal enclave ghaziabad, luxury flats on sale with kids park in koyal enclave ghaziabad, under budget luxury flats for investment in koyal enclave ghaziabad">
    <meta name='description' content='This is the index page'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
<link rel="stylesheet" href="https://amaatraaeroheights.in/public/assets/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.css" integrity="sha512-6lLUdeQ5uheMFbWm3CP271l14RsX1xtx+J5x2yeIDkkiBpeVTNhTqijME7GgRKKi6hCqovwCoBTlRBEC20M8Mg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.css" integrity="sha512-wR4oNhLBHf7smjy0K4oqzdWumd+r5/+6QO/vDda76MW5iug4PT7v86FoEkySIJft3XA0Ae6axhIvHrqwm793Nw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
<link rel="stylesheet" href="https://amaatraaeroheights.in/public/theme1/assets/css/style.css">
<link rel="stylesheet" href="https://amaatraaeroheights.in/public/assets/css/color.css">
<link rel="stylesheet" href="https://amaatraaeroheights.in/public/assets/css/new.font.family.css">

<link href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css" ref="stylesheet" />
<!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" /> -->
<!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" /> -->
<!-- <link href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick.min.css" rel="stylesheet" media="all" /> -->
<!-- <link href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick-theme.css" rel="stylesheet" media="all" /> -->    <style>
    a {
        text-decoration: none !important;
    }
    
     #paymentPopup {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5); 
        z-index: 9999;
        display: flex;
        justify-content: center;
        align-items: center;
        backdrop-filter: blur(8px); 
    }

    .modal-content {
        background-color: white;
        margin: 10%;
        padding: 20px;
        border-radius: 5px;
        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.5);
    }

    #appo-button {
        position: fixed;
        bottom: 50%;
        right: -500%;
        transform: translateY(50%);
        z-index: 9999;
        transition: right .5s;
    }

    #appo-button.button-open {
        right: 10px !important;
    }

    #appointment-booking {
        position: fixed;
        bottom: 50%;
        right: -500%;
        z-index: 9999;
        transform: translateY(50%) scale(0);
        transition: right .5s, transform 1s;
    }

    #appointment-booking.booking-open {
        right: 0 !important;
        transform: translateY(50%) scale(1) !important;
    }

    #appo-button-close {
        position: absolute;
        bottom: 15px;
        right: 10px;
    }
    .error-text-font{
        font-size: 11px !important;
    }
     .iframe iframe{
        width:100%;
    }
</style>

    <style>
        :root {
            --header_background: #26a1df;
            --header_text: #ffffff;
            --navbar_background: #ffffff;
            --navbar_text: #26a1df;
            --searchbar_color: #ffffff;
            --searchbar_button_color: #000000;
            --inquiry_button_color: #074597;
            --footer_background: #ffffff;
            --footer_text_color: #26a1df;
            --copyright_background: #050505;
            --copyright_text_color: #ffffff;
        }
        body.theme-custom {
            --bs-orange-100: #23e7bf;
            --bs-primary-rgb: 35,231,191;
        }
        .custom-text-color p,
        .custom-text-color {
            color: #050505 !important;
        }
    </style>
</head>

<body class="theme-custom">
    <div class="header-background-color ">
    <div class="container-fluid header-padding d-flex justify-content-between py-1">
        <div class="first-columns d-flex align-items-center">
            <ul class="links list-unstyled  d-flex mb-0">
                <li class="pe-4"> <a href="" class="text-light header-text"><i class="fa-solid fa-phone"></i></a> </li>
                <li class="pe-4 "><a href="tel:+91 97111 33226" class="header-text text-decoration-none fw-bold number-hover"> +91 97111 33226</a></li>
                <li class="pe-4"> <a target="_blank" href="https://wa.me/+91 97111 33226?text=Hi%27,%20like%20to%20chat%20with%20you" class=" header-text text-success"><i class="fa-brands fa-whatsapp fs-5"></i></a> </li>
                <li class="pe-4"> <a href="" class="text-light header-text"> <i class="fa-solid fa-comment-dots fs-5"></i></a></li>
            </ul>
        </div>

        <div class="second-columns">
            <ul class="links list-unstyled text-light d-flex mb-0">
                <li>
                    <button class="btn inquiry_button_color search-btn rounded-pill ms-2 responsive-btn btn-sm" data-bs-target="#inquiryModal" data-bs-toggle="modal" type="submit">Make An Inquiry</button>
                </li>
            </ul>
        </div>
    </div>
</div>
 
<input type="hidden" id="baseUrl" value="https://amaatraaeroheights.in" />
<input type="hidden" id="checkError" value="0" />

<nav class="navbar navbar-expand-md navbar-background p-0 sticky-top " style="top: -1px;">
    <div class="container-fluid header-padding">
        <a class="navbar-brand" href="https://amaatraaeroheights.in">
        <img class="logo horizontal-logo assets-img-header-logo-png" src="https://amaatraaeroheights.in/public/uploads/img/business_logo/1757564635_6411623b5b9f8af7bf39.png" alt="forecastr logo" width="" height="70px">
        </a>
        <button class="navbar-toggler" type="button" style="line-height:inherit;" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"><i class="fa-solid fa-bars"></i></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item  m-0">
                <a class="nav-link  text-nowrap" target="" href="https://amaatraaeroheights.in/" 
                   >
                    Home                </a>
                            </li>
                    <li class="nav-item  m-0">
                <a class="nav-link  text-nowrap" target="" href="https://amaatraaeroheights.in/about" 
                   >
                    About Us                </a>
                            </li>
                    <li class="nav-item  m-0">
                <a class="nav-link  text-nowrap" target="" href="https://amaatraaeroheights.in/project_features" 
                   >
                    Project Features                </a>
                            </li>
                    <li class="nav-item  m-0">
                <a class="nav-link  text-nowrap" target="" href="https://amaatraaeroheights.in/floor_plan" 
                   >
                    Floor Plan                </a>
                            </li>
                    <li class="nav-item  m-0">
                <a class="nav-link  text-nowrap" target="" href="https://amaatraaeroheights.in/master_plan" 
                   >
                    Master Plan                </a>
                            </li>
                    <li class="nav-item  m-0">
                <a class="nav-link  text-nowrap" target="" href="https://amaatraaeroheights.in/contact" 
                   >
                    Contact                </a>
                            </li>
        
   
    <li class="nav-item m-0">
    <a class="nav-link text-nowrap" href="https://drive.google.com/file/d/1JS80jO1peED2n7ckInxlY0VdAB9oDMKo/view" target="_blank">
        Payment Plan
    </a>
</li>


    <li class="w-75">
        <form class="form-inline d-flex" method="post" action="search">
            <input name="search" value="" id="search" 
                   class="form-control mr-sm-2 rounded-0 searchbar_color searchbar" 
                   type="search" placeholder="Search" aria-label="Search" 
                   style="width: 200px!important;" required>
            <button class="btn searchbar_button_color search-btn my-2 my-sm-0 rounded-0" type="submit">
                Search
            </button>
        </form>
    </li>
</ul>

        </div>
    </div>
</nav>

<!-- Modal -->
<div class="modal fade" id="inquiryModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header modal-bg-color">
                <h5 class="modal-title text-light fw-bold" id="exampleModalLabel">Make an Inquiry</h5>
                <button type="button" class="btn-close bg-light" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form class="contact-form">
                    <div class="row">
                        <div class="form-group col-md-12">
                            <label for="name">Your Name</label>
                            <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required="">
                        </div>
                        <div class="form-group col-md-12 mt-3">
                            <label for="name">Mobile Number</label>
                            <input type="text" class="form-control" maxlength="10" name="number" id="number" placeholder="Mobile number" required="">
                        </div>
                        <div class="form-group col-md-12 mt-3">
                            <label for="enqEmail">Email</label>
                            <input type="email" class="form-control" name="enqEmail" id="enqEmail" placeholder="Email address" required="">
                        </div>
                    </div>
                    <div class="form-group mt-3">
                        <label for="name">Your Message</label>
                        <textarea class="form-control" name="message" id="message" rows="3" required=""></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary rounded-pill" data-bs-dismiss="modal">Close</button>
                <button type="button" id="sendMsg" class="btn btn-color text-white rounded-pill ">
                    Send
                </button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="testimonialModalShow" tabindex="-1" role="dialog" aria-labelledby="testimonialModalShowLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="testimonialModalShowLabel">Testimonial</h5>
            </div>
            <div class="modal-body" id="modalBody">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary testimonialModalClose" >Close</button>
            </div>
        </div>
    </div>
</div>
    <!-- Page Content -->
    

<div class="home-page overflow-hidden">

    <div class="container-fluid  d-none" id="appointment-booking">
        <div class="row">
            <div class="col-md-5 offset-md-7">
                

                <form class="contact-form m-3 p-3 card " method="post" action="https://amaatraaeroheights.in/submit-query">
                                        
                    <div class="row">
                        <div class="form-group col-md-12">
                            <label for="bookingName">Name</label>
                            <input value="" type="text" id="bookingName" name="bookingName" class="form-control" placeholder="Your Name">
                            <span class="text-danger error-text-font"></span>
                        </div>
                        <div class="form-group col-md-6 mt-2">
                            <label for="bookingEmail">Email</label>
                            <input value="" type="text" class="form-control" id="bookingEmail" name="bookingEmail" placeholder="Your Email">
                            <span class="text-danger error-text-font"></span>
                        </div>
                        <div class="form-group col-md-6 mt-2">
                            <label for="bookingPhone">Phone</label>
                            <input value="" type="text" class="form-control" id="bookingPhone" name="bookingPhone" maxlength="10" placeholder="Mobile number">
                            <span class="text-danger error-text-font"></span>
                        </div>

                        <div class="form-group col-md-6 mt-2">
                            <label for="bookingDate">Booking Date</label>
                            <input value="" type="date" class="form-control" id="bookingDate" name="bookingDate" placeholder="">
                            <span class="text-danger error-text-font"></span>
                        </div>
                        <div class="form-group col-md-6 mt-2">
                            <label for="bookingTime">Booking Time</label>
                            <select name="bookingTime" id="bookingTime" class="form-control" value="">
                                <option value="">Select Time</option>
                                                                                                            <option value="0" selected >12:00 am</option>
                                        <option value="0:30"  >12:30 am</option>
                                                                                                                                                <option value="1"  >1:00 am</option>
                                        <option value="1:30" >1:30 am</option>
                                                                                                                                                <option value="2"  >2:00 am</option>
                                        <option value="2:30" >2:30 am</option>
                                                                                                                                                <option value="3"  >3:00 am</option>
                                        <option value="3:30" >3:30 am</option>
                                                                                                                                                <option value="4"  >4:00 am</option>
                                        <option value="4:30" >4:30 am</option>
                                                                                                                                                <option value="5"  >5:00 am</option>
                                        <option value="5:30" >5:30 am</option>
                                                                                                                                                <option value="6"  >6:00 am</option>
                                        <option value="6:30" >6:30 am</option>
                                                                                                                                                <option value="7"  >7:00 am</option>
                                        <option value="7:30" >7:30 am</option>
                                                                                                                                                <option value="8"  >8:00 am</option>
                                        <option value="8:30" >8:30 am</option>
                                                                                                                                                <option value="9"  >9:00 am</option>
                                        <option value="9:30" >9:30 am</option>
                                                                                                                                                <option value="10"  >10:00 am</option>
                                        <option value="10:30" >10:30 am</option>
                                                                                                                                                <option value="11"  >11:00 am</option>
                                        <option value="11:30" >11:30 am</option>
                                                                                                                                                <option value="12"  >12:00 pm</option>
                                        <option value="12:30"  >12:30 pm</option>
                                                                                                                                                <option value="13"  >1:00 pm</option>
                                        <option value="13:30" >1:30 pm</option>
                                                                                                                                                <option value="14"  >2:00 pm</option>
                                        <option value="14:30" >2:30 pm</option>
                                                                                                                                                <option value="15"  >3:00 pm</option>
                                        <option value="15:30" >3:30 pm</option>
                                                                                                                                                <option value="16"  >4:00 pm</option>
                                        <option value="16:30" >4:30 pm</option>
                                                                                                                                                <option value="17"  >5:00 pm</option>
                                        <option value="17:30" >5:30 pm</option>
                                                                                                                                                <option value="18"  >6:00 pm</option>
                                        <option value="18:30" >6:30 pm</option>
                                                                                                                                                <option value="19"  >7:00 pm</option>
                                        <option value="19:30" >7:30 pm</option>
                                                                                                                                                <option value="20"  >8:00 pm</option>
                                        <option value="20:30" >8:30 pm</option>
                                                                                                                                                <option value="21"  >9:00 pm</option>
                                        <option value="21:30" >9:30 pm</option>
                                                                                                                                                <option value="22"  >10:00 pm</option>
                                        <option value="22:30" >10:30 pm</option>
                                                                                                                                                <option value="23"  >11:00 pm</option>
                                        <option value="23:30" >11:30 pm</option>
                                                                                                </select>
                            <span class="text-danger error-text-font"></span>
                        </div>
                    </div>
                    <div class="form-group mt-3">
                        <label for="bookingQuery">Query</label>
                        <textarea class="form-control" name="bookingQuery" id="bookingQuery" rows="3"></textarea>
                        <span class="text-danger error-text-font"></span>
                    </div>

                    <div class="text-center mt-4">
                        <button type="submit" id="bookingQuerySmt" class="btn btn-color text-white rounded-pill ">
                            Submit Query
                        </button>
                    </div>
                    <button type="button" id="appo-button-close" class="btn btn-danger text-white rounded ">
                        <i class="fas fa-times"></i>
                    </button>
                </form>
            </div>
        </div>
    </div>
    <div id="appo-button" class="button-open d-none btn search-btn rounded-pill">
        Book an Appointment
    </div>
    <style>
    @keyframes slideInLeft {
        0% {
            transform: translateX(-100%);
            opacity: 0;
        }
        100% {
            transform: translateX(0);
            opacity: 1;
        }
    }

    @keyframes slideInRight {
        0% {
            transform: translateX(100%);
            opacity: 0;
        }
        100% {
            transform: translateX(0);
            opacity: 1;
        }
    }

    @keyframes zoomIn {
        from {
            transform: scale(0);
        }
        to {
            transform: scale(1);
        }
    }

 

    .content-wrapper {
        position: absolute;
    }

    @media screen and (max-width: 768px) {
        .slider-height {
            height: 200px; /* Adjust the height as needed for mobile */
            background-size: cover;
        }

        /* Adjust padding and alignment for smaller screens */
        .flex-column {
            align-items: center;
            padding: 10px;
            text-align: center;
        }

        /* Adjust font sizes for mobile */
        .title {
            font-size: 18px !important; /* Adjust the font size as needed for mobile */
        }

        .description {
            font-size: 10px !important; /* Adjust the font size as needed for mobile */
        }
    }
</style>

<section>
    <div class="one-time">                    <div class="position-relative">
                        <div class="slider-height position-relative" style="background-image: url(https://amaatraaeroheights.in/public/uploads/slider_images/1757753026_6e31617e9bd2ecc65abf.jpg);">
                                                        
                            <div class="row align-items-start flex-column justify-content-center h-100 " style="padding-left: 20px;">
                            <div class="content-wrapper row align-items-start flex-column justify-content-center h-100 " style="padding-left: 20px;"">
                                                                    <div class='detail-box' style="width: fit-content;">
                                                                <h2 class="title " style="color: #ffffff;
                                    font-family: tai_heritage !important;
                                    font-size: 60px;
                                    text-align: left;
                                    animation: slideInLeft 1s ease;                                    animation-fill-mode: forwards;">
                                                                    </h2>
                                
                                                                    </div>
                                                            </div>
                            </div>
                        </div>

                    </div>
                    </div></section>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        // Delay animation after page load
        setTimeout(function() {
            let animatedElements = document.querySelectorAll(".one-time .h-100");
            animatedElements.forEach(function (element) {
                if (!element.classList.contains("already-animated")) {
                    element.classList.add("already-animated");
                }
            });
        }, 500); // Adjust the delay time as needed

        // Check for redundant slider reloads and initialization code
        // Ensure the slider initialization code is executed only once
    });
</script><style>
::-webkit-scrollbar {
  width: 5px;
  height: 4px;
}

::-webkit-scrollbar-track {
  background: #f1f1f1; 
}
 
::-webkit-scrollbar-thumb {
  background: #888; 
  border-radius: 1rem;
}

::-webkit-scrollbar-thumb:hover {
  background: #555; 
}
.update_list{
    width: 100%;
    height: 100px;
    object-fit: cover;
}
</style>

    <section class="mb-4">
        <div class="services2 section-padding">
            <div class="text-center mb-5" data-aos="fade-up" data-aos-duration="1000">
                 <h2 class="text-color text-uppercase fw-bold">Latest Updates</h2>
                <!--<h2><span class="text-color text-uppercase fw-bold">Our Updates</span></h2>-->
            </div>
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="row m-auto">
                        <div class="col-md-12" data-aos="fade-up" data-aos-delay="100" data-aos-duration="1000">
                            <div class="row update">
                                                                            <div class="col-md-4">
                                            <div class="card shadow-lg border-0 me-2">
                                                    <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1777352657_70130e33716ecd6d884a.jpg" class="card-img-top" alt="Avatar" style="height:350px; object-fit: cover;" />
                                                <div class="card-body my-3">
                                                    <h6 class="card-title text-color fw-bold">28-Apr-2026</h6>
                                                    <p class="card-text text-uppercase fw-bold h6 py-2">Pre Launch 3BHK Flats in Koyal Enclave Ghaziabad</p>
                                                </div>
                                                <div class="card-footer">
                                                                                                        <a href="https://amaatraaeroheights.in/updates/pre-launch-3bhk-flats-in-koyal-enclave-ghaziabad">
                                                        <button class="btn btn-color rounded-pill ">
                                                            Read More
                                                        </button>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                                                        <div class="col-md-4">
                                            <div class="card shadow-lg border-0 me-2">
                                                    <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1778129954_73d4376f41aef7d15639.jpg" class="card-img-top" alt="Avatar" style="height:350px; object-fit: cover;" />
                                                <div class="card-body my-3">
                                                    <h6 class="card-title text-color fw-bold">07-May-2026</h6>
                                                    <p class="card-text text-uppercase fw-bold h6 py-2">3 BHK flats in Ghaziabad</p>
                                                </div>
                                                <div class="card-footer">
                                                                                                        <a href="https://amaatraaeroheights.in/updates/3-bhk-flats-in-ghaziabad">
                                                        <button class="btn btn-color rounded-pill ">
                                                            Read More
                                                        </button>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                                                        <div class="col-md-4">
                                            <div class="card shadow-lg border-0 me-2">
                                                    <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1778480790_f04fd1123c33c4031c26.jpg" class="card-img-top" alt="Avatar" style="height:350px; object-fit: cover;" />
                                                <div class="card-body my-3">
                                                    <h6 class="card-title text-color fw-bold">11-May-2026</h6>
                                                    <p class="card-text text-uppercase fw-bold h6 py-2">premium flats in Ghaziabad</p>
                                                </div>
                                                <div class="card-footer">
                                                                                                        <a href="https://amaatraaeroheights.in/updates/premium-flats-in-ghaziabad">
                                                        <button class="btn btn-color rounded-pill ">
                                                            Read More
                                                        </button>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                                                        <div class="col-md-4">
                                            <div class="card shadow-lg border-0 me-2">
                                                    <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1781070276_06d28c43740c897d68b8.webp" class="card-img-top" alt="Avatar" style="height:350px; object-fit: cover;" />
                                                <div class="card-body my-3">
                                                    <h6 class="card-title text-color fw-bold">10-Jun-2026</h6>
                                                    <p class="card-text text-uppercase fw-bold h6 py-2">2 BHK flats in Koyal Enclave</p>
                                                </div>
                                                <div class="card-footer">
                                                                                                        <a href="https://amaatraaeroheights.in/updates/2-bhk-flats-in-koyal-enclave">
                                                        <button class="btn btn-color rounded-pill ">
                                                            Read More
                                                        </button>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="row" style="height: 500px; overflow-y: auto; overflow-x: hidden;">
                                                    <a href="https://amaatraaeroheights.in/updates/buy-3bhk-apartment-in-amaatraa-aero-heights-koyal-enclave" class="hstack gap-3">
                                <div class="col-md-4">
                                    <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1759493730_a7ad6f409d692635837a.png" class="img-fluid update_list">
                                </div>
                                <div class="col-md-8">
                                    <p class="text-color">03-Oct-2025</p>
                                    <h6>Buy 3bhk apartment in Amaatraa Aero heights Koyal Enclave</h6>
                                </div>
                            </a>
                                                    <a href="https://amaatraaeroheights.in/updates/affordable-4-bhk-apartment-in-koyal-enclave-ghaziabad" class="hstack gap-3">
                                <div class="col-md-4">
                                    <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1759220521_12c7db0b58348cc5e475.png" class="img-fluid update_list">
                                </div>
                                <div class="col-md-8">
                                    <p class="text-color">30-Sep-2025</p>
                                    <h6>Affordable 4 bhk Apartment in koyal enclave ghaziabad</h6>
                                </div>
                            </a>
                                                    <a href="https://amaatraaeroheights.in/updates/budget-3-bhk-flats-near-hindon-airport-ghaziabad" class="hstack gap-3">
                                <div class="col-md-4">
                                    <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1758716172_04d3bc05ca7af52ba23e.jpg" class="img-fluid update_list">
                                </div>
                                <div class="col-md-8">
                                    <p class="text-color">24-Sep-2025</p>
                                    <h6>budget 3 bhk flats near hindon airport Ghaziabad</h6>
                                </div>
                            </a>
                                                    <a href="https://amaatraaeroheights.in/updates/amaatra-aero-heights" class="hstack gap-3">
                                <div class="col-md-4">
                                    <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1758540309_839c2f3d2179e5f822d7.jpg" class="img-fluid update_list">
                                </div>
                                <div class="col-md-8">
                                    <p class="text-color">22-Sep-2025</p>
                                    <h6>Amaatra Aero Heights</h6>
                                </div>
                            </a>
                                                    <a href="https://amaatraaeroheights.in/updates/budget-2-bhk-luxury-flats-for-sale-in-koyal-enclave-ghaziabad" class="hstack gap-3">
                                <div class="col-md-4">
                                    <img src="https://amaatraaeroheights.in/public/uploads/post_updates_images/1757912161_8fb88b679bbb52eccdbe.jpg" class="img-fluid update_list">
                                </div>
                                <div class="col-md-8">
                                    <p class="text-color">15-Sep-2025</p>
                                    <h6>Budget 2 bhk Luxury Flats for sale in koyal enclave Ghaziabad</h6>
                                </div>
                            </a>
                                            </div>
                     <div class="p-3 text-end">
                        <a href ="https://amaatraaeroheights.in/update.html"   class="btn search-btn rounded-pill ms-2 responsive-btn" target="_blank">
                            See More
                        </a>
                    </div>
                </div>
                
            </div>
        </div>
    </section>
<style>
    @keyframes slideInLeft {
        0% {
            transform: translateX(-100%);
            opacity: 0;
        }
        100% {
            transform: translateX(0);
            opacity: 1;
        }
    }

    @keyframes slideInRight {
        0% {
            transform: translateX(100%);
            opacity: 0;
        }
        100% {
            transform: translateX(0);
            opacity: 1;
        }
    }

    @keyframes zoomIn {
        from {
            transform: scale(0);
        }
        to {
            transform: scale(1);
        }
    }

 

    .content-wrapper {
        position: absolute;
    }

    @media screen and (max-width: 768px) {
        .slider-height {
            height: 200px; /* Adjust the height as needed for mobile */
            background-size: cover;
        }

        /* Adjust padding and alignment for smaller screens */
        .flex-column {
            align-items: center;
            padding: 10px;
            text-align: center;
        }

        /* Adjust font sizes for mobile */
        .title {
            font-size: 18px !important; /* Adjust the font size as needed for mobile */
        }

        .description {
            font-size: 10px !important; /* Adjust the font size as needed for mobile */
        }
    }
</style>

<section>
    </section>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        // Delay animation after page load
        setTimeout(function() {
            let animatedElements = document.querySelectorAll(".one-time .h-100");
            animatedElements.forEach(function (element) {
                if (!element.classList.contains("already-animated")) {
                    element.classList.add("already-animated");
                }
            });
        }, 500); // Adjust the delay time as needed

        // Check for redundant slider reloads and initialization code
        // Ensure the slider initialization code is executed only once
    });
</script><style>
    @keyframes slideInLeft {
        0% {
            transform: translateX(-100%);
            opacity: 0;
        }
        100% {
            transform: translateX(0);
            opacity: 1;
        }
    }

    @keyframes slideInRight {
        0% {
            transform: translateX(100%);
            opacity: 0;
        }
        100% {
            transform: translateX(0);
            opacity: 1;
        }
    }
</style>

            <section style="margin-block:30px">
                <div class="container-fluid px-0 mx-0">
                    <div class="row mx-0 flex-row-reverse aos-init aos-animate" data-aos="fade-up" data-aos-duration="1000">
                    <div class="d-flex justify-content-center flex-column 
                    col-md-12 bg-white text-center">
                    <div class="inside-div p-4" style="animation: slideInRight 1s ease;">
                        <h2 class="pb-3 fw-bolder custom-text-color">Premium Location in Koyal Enclave Ghaziabad</h2>
                        <div class="text-div text-alignment text-center">
                            <p style="text-align:justify">Aero Heights is strategically located in Koyal Enclave, Ghaziabad, offering residents the perfect balance of peaceful living and seamless connectivity. Surrounded by well-developed infrastructure, reputed schools, healthcare centers, shopping destinations, and entertainment hubs, the location ensures that everything you need is just a few minutes away. With excellent road connectivity to Delhi, Noida, and major NCR hubs, Aero Heights places you at the heart of convenience while letting you enjoy a serene lifestyle away from the city&rsquo;s chaos.</p>

<p style="text-align:justify"><strong>Why Invest in Aero Heights?</strong><br />
&nbsp;</p>

<p style="text-align:justify">Investing in Aero Heights means securing a home in one of the fastest-growing residential destinations of Ghaziabad. With its prime location in Koyal Enclave, the project combines luxury, convenience, and long-term value.<br />
<br />
✅ Strategic Location &ndash; Excellent connectivity to Delhi, Noida, and other NCR hubs.<br />
✅ Modern Lifestyle &ndash; Spacious 2, 3 &amp; 4 BHK apartments with world-class amenities.<br />
✅ High Appreciation Potential &ndash; Rapid infrastructure growth in Koyal Enclave ensures strong returns.<br />
✅ Trusted Developer &ndash; Built on the promise of &ldquo;Building Trust, Not Just Buildings&rdquo;.<br />
✅ Ready Social Infrastructure &ndash; Schools, hospitals, malls, and daily conveniences nearby.</p>

<ul>
</ul>
                        </div>
                    </div>
                </div>

                        
                    </div>
                </div>
            </section>
<style>
    @keyframes slideInLeft {
        0% {
            transform: translateX(-100%);
            opacity: 0;
        }
        100% {
            transform: translateX(0);
            opacity: 1;
        }
    }

    @keyframes slideInRight {
        0% {
            transform: translateX(100%);
            opacity: 0;
        }
        100% {
            transform: translateX(0);
            opacity: 1;
        }
    }
</style>

<style>
    @keyframes slideInLeft {
        0% {
            transform: translateX(-100%);
            opacity: 0;
        }
        100% {
            transform: translateX(0);
            opacity: 1;
        }
    }

    @keyframes slideInRight {
        0% {
            transform: translateX(100%);
            opacity: 0;
        }
        100% {
            transform: translateX(0);
            opacity: 1;
        }
    }
</style>

            <section style="margin-block:0">
                <div class="container-fluid px-0 mx-0">
                    <div class="row mx-0  aos-init aos-animate" data-aos="fade-up" data-aos-duration="1000">
                    <div class="d-flex justify-content-center flex-column 
                    col-md-6 bg-primary">
                    <div class="inside-div p-4" style="animation: slideInLeft 1s ease;">
                        <h2 class="pb-3 fw-bolder custom-text-color">Projects and Features</h2>
                        <div class="text-div text-alignment ">
                            <table id="Custom_slider_table">
	<tbody>
		<tr>
			<td>
			<p>Aero Heights enjoys a strategic location in Koyal Enclave, Ghaziabad, making it one of the most sought-after residential destinations in NCR. The project ensures seamless connectivity to major hubs while offering a peaceful living environment.</p>

			<ul>
				<li>Modern Clubhouse with indoor activities</li>
				<li>Landscaped Gardens &amp; open green spaces</li>
				<li>Children&rsquo;s Play Area &amp; family zones</li>
				<li>Multipurpose Banquet and Community Hall</li>
				<li>Swimming Pool with Seperate kids Pool</li>
				<li>Fully Equipped Gymnasium and Fitness Center</li>
				<li>Jogging Track and Cycling Path</li>
				<li>Ample Car Parking Space</li>
				<li>High Speed Elevators</li>
				<li>24X7 Water Supply and Power Backup</li>
				<li>In House shopping and Daily Convenience Store</li>
				<li>24X7 Security with CCTV Surveillance</li>
				<li>Firefighting Systems as per latest norms</li>
			</ul>
			</td>
		</tr>
	</tbody>
</table>
                        </div>
                    </div>
                </div>

                                                <div class="col-md-6 px-0">
                            <div class="side-img h-100" style="animation: slideInRight 1s ease;">
                                <img src="https://amaatraaeroheights.in/public/uploads/custom_images/1757760560_325e5701a01ab72674c5.jpg" class="h-100" alt="" width="100%">
                            </div>
                        </div>
                        
                    </div>
                </div>
            </section>
<style>
    @keyframes slideInLeft {
        0% {
            transform: translateX(-100%);
            opacity: 0;
        }
        100% {
            transform: translateX(0);
            opacity: 1;
        }
    }

    @keyframes slideInRight {
        0% {
            transform: translateX(100%);
            opacity: 0;
        }
        100% {
            transform: translateX(0);
            opacity: 1;
        }
    }
</style>

            <section style="margin-block:0">
                <div class="container-fluid px-0 mx-0">
                    <div class="row mx-0 flex-row-reverse aos-init aos-animate" data-aos="fade-up" data-aos-duration="1000">
                    <div class="d-flex justify-content-center flex-column 
                    col-md-6 bg-primary">
                    <div class="inside-div p-4" style="animation: slideInRight 1s ease;">
                        <h2 class="pb-3 fw-bolder custom-text-color">Location Advantages</h2>
                        <div class="text-div text-alignment ">
                            <p style="text-align:justify">Aero Heights enjoys a strategic location in Koyal Enclave, Ghaziabad, making it one of the most sought-after residential destinations in NCR. The project ensures seamless connectivity to major hubs while offering a peaceful living environment.</p>

<ul>
	<li style="text-align:justify">&nbsp;Connectivity to Delhi &amp; Noida via NH-24 &amp; Delhi&ndash;Meerut Expressway</li>
	<li style="text-align:justify">&nbsp;Just 10 mins from Anand Vihar ISBT &amp; Railway Station</li>
	<li style="text-align:justify">&nbsp;15 mins from Hindon Airport</li>
	<li style="text-align:justify">&nbsp;Close to proposed metro stations and rapid transport corridors</li>
	<li style="text-align:justify">&nbsp;Surrounded by reputed schools, colleges &amp; coaching centers</li>
	<li style="text-align:justify">&nbsp;Proximity to hospitals, shopping malls &amp; daily conveniences</li>
	<li style="text-align:justify">&nbsp;Easy access to business districts &amp; IT hubs of Noida &amp; Ghaziabad</li>
</ul>
                        </div>
                    </div>
                </div>

                                                <div class="col-md-6 px-0">
                            <div class="side-img h-100" style="animation: slideInLeft 1s ease;">
                                <img src="https://amaatraaeroheights.in/public/uploads/custom_images/1757533643_d5e49cb38f83626a03fd.gif" class="h-100" alt="" width="100%">
                            </div>
                        </div>
                        
                    </div>
                </div>
            </section>
<style>
    .marquee-container {
        overflow: hidden;
        white-space: nowrap;
        position: relative;
       
        border-bottom: 2px solid #ccc; /* Add a bottom border */
    }

    .container-fluid {
      
      padding : 10 !important;
    }

    .marquee-content {
        display: inline-block;
        animation: marquee-slide 30s linear infinite;
        padding: 10px; /* Add padding for space between border and images */
    }

    .marquee-content img {
        margin-right: 20px; /* Add spacing between images */
    }

    @keyframes marquee-slide {
        0% { transform: translateX(0%); }
        100% { transform: translateX(-100%); }
    }
    .logoSliderHeading {
        border-top: 2px solid #ccc; /* Add a top border */
    }

    .image-container {
    position: relative;
    display: inline-block;
    }

    .image-container::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        cursor: not-allowed; /* Show disabled cursor */
        
    }
</style>

    <!--<section>-->
    <!--    <div class="container-fluid logoSliderHeading">-->
    <!--        <div class="text-center m-auto pt-4">-->
    <!--            <h1 class="pb-3 fw-bold custom-text-color">Project Facilities</h1>-->
    <!--            <hr class="m-auto bg-success" style="width: 80px; height: 5px">-->
    <!--            <p class="pt-2"></p>-->
    <!--        </div>-->
    <!--        <div class="row">-->
    <!--             Add your content here -->
    <!--        </div>-->
    <!--    </div>-->
    <!--</section>-->

<script>
    document.addEventListener('contextmenu', function(e) {
    e.preventDefault(); // Prevent right-click menu from appearing
});
</script>
 <script>
    document.querySelector('.image-container:last-child img').addEventListener('contextmenu', function(e) {
        e.preventDefault(); // Prevent right-click menu from appearing
    });
</script> -->

    <section class="mb-4">
        <div class="contact section-padding">
            <div class="text-center mb-5">
                <h1>Contact us <span class="text-color text-uppercase fw-bold">To Get Started</span></h1>
            </div>
            <div class="row py-4 gx-5">
                <div class="col-md-6 d-flex">
                    <div class="w-100 top-border iframe">
                        <!--<iframe class="location-height" src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d12097.433213460943!2d-74.0062269!3d40.7101282!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xb89d1fe6bc499443!2sDowntown+Conference+Center!5e0!3m2!1smk!2sbg!4v1539943755621" frameborder="0" style="border:0; width: 100%;border-radius:16px; height:320px;"></iframe>-->
                         <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3499.415623419941!2d77.32852577550354!3d28.707122575624027!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390cfbcb3fb5e8cf%3A0x664c26ee50a64392!2sKoyal%20Enclave!5e0!3m2!1sen!2sin!4v1757533861432!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>                    </div>
                </div>
                <div class="col-md-6">
                    <div class="top-border responsive-form">
                        <section style="background: white; border: solid black 2px; padding-block: 30px;" id="businessQueryId111">
    <div class="text-center mb-5">
        <h2><span class="text-color text-uppercase fw-bold">Business Query</span></h2>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <form class="contact-form">
                                                                            <div class="row">
                        <div class="form-group col-md-6">
                            <label for="name">Your Name</label>
                            <input type="text" value="" name="name" class="form-control userName" id="userName111" placeholder="Your Name" />
                        </div>
                        <div class="form-group col-md-6">
                            <label for="name">Mobile Number</label>
                            <input type="text" id="userPhone111"  class="form-control userName" value="" name="number" maxlength="10" placeholder="Mobile Number" />
                        </div>
                    </div>
                    <div class="form-group mt-3">
                        <label for="name">Email Address</label>
                        <input type="text" value=""class="form-control userName" id="userEmail111" name="email" placeholder="Your Email" />
                    </div>
                    <div class="form-group mt-3">
                        <label for="name">Message</label>
                        <textarea class="form-control userName" name="message" id="userMessage111" rows="3"></textarea>
                    </div>

                    <div class="text-center mt-4">
                        <button type="button" onclick="sendMessage(111)" class="btn btn-primary text-white rounded-pill sendMessage" id="sendMessage111">
                            Send Message
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

    <style>
    .fb-box{
        height: 350px;
        width:360px;
    }
    .mybox {
        margin:40px !important;
    }
    @media only screen and (max-width: 767px) {
        #facebook-iframe {
            width: 100% !important;
            height: 500px !important; /* Adjust height as needed for portrait mode */
        }
        .fb-box{
        height: 600px;
        width:360px;
        }
         .mybox {
        margin:0px !important;
        }
    }
</style>
<footer id="footer">
    <div class="footer-top footer-background text-light py-5">
          <div class="container mybox">
            <div class="row g-5 justify-content-center">
                <div class="col-md-6">
                    <div class="footer-info shadow text-center">
                        <h3 class="text-center custom-text-color fw-bold">Get In Touch</h3>
                        <div class= "row">
                            
                            <div class="col-md-12">
                                <p class="pb-3 m-0">
                                    <em>
                                        Corporate Office Address :- GH-02, Jaipuria Sunrise Greens, Opp Manipal Hospital, Ghaziabad - 201002.<br>RERA No- UPRERAPRJ15601<br>www.up-rera.in                                    </em>
                                </p>
                                <strong>Phone:</strong> +91 97111 33226, <br> <strong>Email:</strong> sales@amatragroup.com<br>
                                </p>
                            </div>
                            <div class="col-md-12">
                                <p class="pb-3 m-0">
                                    <em>
                                        Regional Corporate Office: - Unit Number - 511, SG Brave Road, Wagle Estate, Thane (West), Maharashtra, 400604.                                    </em>
                                </p>
                                
                                                                         <strong>Alternate Number: </strong> 18001034240<br>
                                                                     <strong>Alternate Email: </strong> maninderbansal@gmail.com<br>
                                                            </div>
                        </div>
                    </div>
                </div> 
                
                <!-- <div class="col-md-3 newsletter">
                    <h3 class="fw-bold custom-text-color">Our Newsletter</h3>
                    <div id="business_description">
                        
                    <p></p>
                    </div>
                    <form action="" method="post">
                        <input type="email" name="email" class="py-1 border-0 searchbar_color">
                        <input type="submit" class="btn-color custom-text-color border-0 py-1 rounded" value="Subscribe">
                    </form>
                </div> -->

                <div class="col-md-3 quick-links text-center">
                    <h3 class="fw-bold custom-text-color">Quick Links</h3>
                    <div>
                        <ul class="list-unstyled" style="padding-left: 0pt;">
                            <li style="text-decoration: underline; padding-bottom:20px; font-size:18px;"><a class="custom-text-color" href="">Home</a></li><li style="text-decoration: underline; padding-bottom:20px; font-size:18px;"><a class="custom-text-color" href="about">About Us</a></li><li style="text-decoration: underline; padding-bottom:20px; font-size:18px;"><a class="custom-text-color" href="project_features">Project Features</a></li><li style="text-decoration: underline; padding-bottom:20px; font-size:18px;"><a class="custom-text-color" href="floor_plan">Floor Plan</a></li><li style="text-decoration: underline; padding-bottom:20px; font-size:18px;"><a class="custom-text-color" href="master_plan">Master Plan</a></li><li style="text-decoration: underline; padding-bottom:20px; font-size:18px;"><a class="custom-text-color" href="contact">Contact</a></li>                        </ul>
                    </div>
                </div>





                            <div class="col-md-3">
                                <div class="fb-box mx-auto" style="background-color: #f8f9fa; padding: 10px; border-radius: 5px; height:auto; margin-bottom:5px;">
                                    <div class="social-links text-center footer-center">
                                        <a target="_blank" href="https://twitter.com/TCS?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor" class="twitter text-light me-1 rounded text-center fs-6" style="color: #1DA1F2 !important; font-size: 24px;">
                                            <i class="fa-brands fa-twitter-square"></i>
                                        </a>
                                        <a target="_blank" href="https://www.facebook.com/Amaatragroup" class="facebook text-light me-1 rounded text-center fs-6" style="color: #1877F2!important; font-size: 24px;">
                                            <i class="fa-brands fa-facebook-square"></i>
                                        </a>
                                        <a target="_blank" href="https://www.instagram.com/tcsglobal/?hl=en" class="instagram text-light me-1 rounded text-center fs-6" style="color: #C13584 !important; font-size: 24px;">
                                            <i class="fa-brands fa-instagram-square"></i>
                                        </a>
                                        <a target="_blank" href="https://www.youtube.com/channel/UCaHyiyvJp4hhPNhIU7r9uqg" class="google-plus text-light me-1 rounded text-center fs-6" style="color: #FF0000 !important; font-size: 24px;">
                                            <i class="fa-brands fa-youtube"></i>
                                        </a>
                                        <a target="_blank" href="https://in.linkedin.com/company/tata-consultancy-services" class="linkedin text-light me-1 rounded text-center fs-6" style="color: #0077B5 !important; font-size: 24px;">
                                            <i class="fa-brands fa-linkedin ml-2"></i>
                                        </a>
                                    </div>
                                         <iframe id="facebook-iframe" style="margin: auto; display: flex; margin-bottom:10px:width: 100%;height:100%;" src="https://www.facebook.com/plugins/page.php?href=https://www.facebook.com/Amaatragroup&tabs=timeline&width=345&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="270" height="300" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></iframe>
                                  </div>
                                  <section class="newsletter-section text-center py-3">
                                <h3 class="fw-bold custom-text-color w-100">Our Newsletter</h3>
                                <hr class="m-auto bg-danger mb-3" style="width: 80px; height: 5px">
                                    <marquee behavior="scroll" direction="left" style="width:400px;">
                                        <!-- Newsletter content here -->
                                        Aero Heights enjoys a strategic location in Koyal Enclave, Ghaziabad, making it one of the most sought-after residential destinations in NCR. The project ensures seamless connectivity to major hubs while offering a peaceful living environment.                                    </marquee>
                                </section>
                                  
                             </div>
            </div>
        </div>
        
    </div>
</footer>



<section class="copyright-background">
    <div class="row">
        <div class="col-md-12 text-center copyright-text">
        © 2026 Advertising India        </div>
    </div>
</section>



<!-- <a id="button" class="scroll-to-top scroll-to-target  position-fixed text-light fs-6 text-center rounded-circle border-0" data-target="html">
    <span class="fa fa-arrow-up">
    </span>
</a> -->    <script src="https://amaatraaeroheights.in/public/assets/js/jquery.min.js"></script>
<script src="https://amaatraaeroheights.in/public/assets/js/bootstrap.bundle.min.js"></script>
<script src="https://amaatraaeroheights.in/public/assets/js/jquery.validate.min.js"></script>
<script src="https://amaatraaeroheights.in/public/assets/js/additional-methods.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js" integrity="sha512-XtmMtDEcNz2j7ekrtHvOVR4iwwaD6o/FUJe6+Zq+HgcCsk3kj4uSQQR8weQ2QVj1o0Pk6PwYLohm206ZzNfubg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="https://amaatraaeroheights.in/public/assets/js/script.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.min.js"></script>

<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick.min.js"></script> -->
<!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script></script> -->
<script type="text/javascript" src="https://amaatraaeroheights.in/public/theme1/assets/js/pages/common.js"></script>
    <script>
    $(function() {
        AOS.init();

        //open close appointment form
        $('#appo-button-close').on('click', function() {
            $('#appointment-booking').removeClass('booking-open');
            $('#appo-button').addClass('button-open');
        });
        $('#appo-button').on('click', function() {
            $('#appointment-booking').addClass('booking-open');
            $('#appo-button').removeClass('button-open');
        });
        
         
    });
</script>

    
            <script defer>
            $(function() {
                var eppathurl = window.location.origin + window.location.pathname;
                var eptagmanage = new XMLHttpRequest();
                var getDataUrl = "https://amaatraaeroheights.in" + '/posts/getAllData/';
                var currentUrl = "https://amaatraaeroheights.in/";
                getDataUrl = btoa(getDataUrl);
                eptagmanage.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                        if (this.response !== 0) {
                            var temp = this.response.split("||||||||||");
                            $("head").find("title").remove();
                            $('head').append(temp[0]);
                            $("body").append(temp[1]);
                        }
                    }
                };
                eptagmanage.open("POST", atob(getDataUrl) + btoa(currentUrl));
                eptagmanage.send();
            });

            document.addEventListener('DOMContentLoaded', function() {
                var keywords = [{"keyword":"amaatra aero heights flats in koyal enclave Ghaziabad","page_url":"https:\/\/amaatraaeroheights.in\/"},{"keyword":"ammatra aero heights in koyal enclave ghaziabad","page_url":"https:\/\/amaatraaeroheights.in\/"},{"keyword":"budget 3 bhk flats near hindon airport Ghaziabad","page_url":"https:\/\/amaatraaeroheights.in\/"},{"keyword":"2 and 3 bhk flats near hindon airport ghaziabad","page_url":"https:\/\/amaatraaeroheights.in\/"},{"keyword":"pre launche luxury flats for investment in koyal enclave ghaziabad","page_url":"https:\/\/amaatraaeroheights.in\/"},{"keyword":"affordable 2 bhk flats in koyal enclave ghaziabad","page_url":"https:\/\/amaatraaeroheights.in\/"},{"keyword":"2 bhk flats on high rise society in koyal enclave ghaziabad","page_url":"https:\/\/amaatraaeroheights.in\/"},{"keyword":"premium flats near by delhi in koyal enclave ghaziabad","page_url":"https:\/\/amaatraaeroheights.in\/"},{"keyword":"2 and 3 BHK flats near by koyal enclave ghaziabad","page_url":"https:\/\/amaatraaeroheights.in\/"},{"keyword":"luxury flats for sale with swimming pool in koyal enclave ghaziabad","page_url":"https:\/\/amaatraaeroheights.in\/"},{"keyword":"luxury flats on sale with kids park in koyal enclave ghaziabad","page_url":"https:\/\/amaatraaeroheights.in\/"},{"keyword":"under budget luxury flats for investment in koyal enclave ghaziabad","page_url":"https:\/\/amaatraaeroheights.in\/"},{"keyword":"budget 3 bhk flats near hindon airport Ghaziabad","page_url":"https:\/\/amaatraaeroheights.in\/"},{"keyword":"2 and 3 bhk flats near hindon airport ghaziabad","page_url":"https:\/\/amaatraaeroheights.in\/"},{"keyword":"pre launche luxury flats for investment in koyal enclave ghaziabad","page_url":"https:\/\/amaatraaeroheights.in\/"},{"keyword":"affordable 2 bhk flats in koyal enclave ghaziabad","page_url":"https:\/\/amaatraaeroheights.in\/"},{"keyword":"2 bhk flats on high rise society in koyal enclave ghaziabad","page_url":"https:\/\/amaatraaeroheights.in\/"},{"keyword":"premium flats near by delhi in koyal enclave ghaziabad","page_url":"https:\/\/amaatraaeroheights.in\/"},{"keyword":"2 and 3 BHK flats near by koyal enclave ghaziabad","page_url":"https:\/\/amaatraaeroheights.in\/"},{"keyword":"luxury flats for sale with swimming pool in koyal enclave ghaziabad","page_url":"https:\/\/amaatraaeroheights.in\/"},{"keyword":"luxury flats on sale with kids park in koyal enclave ghaziabad","page_url":"https:\/\/amaatraaeroheights.in\/"},{"keyword":"under budget luxury flats for investment in koyal enclave ghaziabad","page_url":"https:\/\/amaatraaeroheights.in\/"}];
                if (keywords && keywords.length > 0) {
                    var keywordString = keywords.map(function(keyword) {
                        return keyword.keyword;
                    }).join(', ');
                    var metaKeywordsTag = document.createElement('meta');
                    metaKeywordsTag.name = 'keywords';
                    metaKeywordsTag.content = keywordString;
                    document.head.appendChild(metaKeywordsTag);
                }
            });
        </script>
    </body>
</html>
